// public/js/auth.js
const API_URL = 'http://localhost:3000/api';

// Handle login
async function login(event) {
    event.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    try {
        const response = await fetch(`${API_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, password }),
        });
        
        const data = await response.json();
        
        if (response.ok) {
            // Store user info in localStorage
            localStorage.setItem('userId', data.id);
            localStorage.setItem('username', data.username);
            
            // Redirect to main page
            window.location.href = '/index.html';
        } else {
            alert(data.error || 'Login failed');
        }
    } catch (error) {
        console.error('Error during login:', error);
        alert('An error occurred during login');
    }
}

// Handle registration
async function register(event) {
    event.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    try {
        const response = await fetch(`${API_URL}/auth/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, password }),
        });
        
        const data = await response.json();
        
        if (response.ok) {
            alert('Registration successful! Please login.');
            window.location.href = '/login.html';
        } else {
            alert(data.error || 'Registration failed');
        }
    } catch (error) {
        console.error('Error during registration:', error);
        alert('An error occurred during registration');
    }
}

// Handle logout
function logout() {
    // Clear user data from localStorage
    localStorage.removeItem('userId');
    localStorage.removeItem('username');
    
    // Redirect to login page
    window.location.href = '/login.html';
}

// Check auth status on page load
function checkAuth() {
    const userId = localStorage.getItem('userId');
    const currentPage = window.location.pathname;
    
    // If user is logged in and tries to access login/register pages,
    // redirect to main page
    if (userId && (currentPage === '/login.html' || currentPage === '/register.html')) {
        window.location.href = '/index.html';
    }
    
    // If user is not logged in and tries to access main page,
    // redirect to login page
    if (!userId && currentPage === '/index.html') {
        window.location.href = '/login.html';
    }
}

// Run auth check when page loads
document.addEventListener('DOMContentLoaded', checkAuth);