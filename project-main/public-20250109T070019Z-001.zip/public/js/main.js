// public/js/main.js
const API_URL = 'http://localhost:3000/api';
let userId = localStorage.getItem('userId');
const username = localStorage.getItem('username');

// Check if user is logged in
if (!userId) {
    window.location.href = '/login.html';
} else {
    document.getElementById('username').textContent = `Welcome, ${username}!`;
}

// Display tasks
function displayTasks(tasks) {
    const container = document.getElementById('tasksContainer');
    container.innerHTML = '';
    
    if (tasks.length === 0) {
        container.innerHTML = '<p class="no-tasks">No tasks found. Add a new task!</p>';
        return;
    }
    
    tasks.forEach(task => {
        const taskElement = document.createElement('div');
        taskElement.className = `task-card ${task.status === 'completed' ? 'completed' : ''}`;
        
        taskElement.innerHTML = `
            <div class="task-header">
                <h3 class="task-title" id="title-${task.id}">${task.title}</h3>
                <div class="task-actions">
                    <button onclick="editTask(${task.id})" class="edit-btn">Edit</button>
                    <button onclick="deleteTask(${task.id})" class="delete-btn">Delete</button>
                </div>
            </div>
            <p class="task-description" id="desc-${task.id}">${task.description || ''}</p>
            <div class="task-footer">
                <button onclick="toggleTaskStatus(${task.id}, '${task.status}')" 
                        class="status-btn ${task.status === 'completed' ? 'completed' : ''}">
                    ${task.status === 'completed' ? 'Mark Incomplete' : 'Mark Complete'}
                </button>
                <span class="task-date">Created: ${new Date(task.created_at).toLocaleDateString()}</span>
            </div>
        `;
        
        container.appendChild(taskElement);
    });
}

// Fetch all tasks
async function fetchTasks() {
    try {
        const response = await fetch(`${API_URL}/tasks`, {
            headers: {
                'user-id': userId
            }
        });
        if (!response.ok) throw new Error('Failed to fetch tasks');
        const tasks = await response.json();
        displayTasks(tasks);
    } catch (error) {
        console.error('Error fetching tasks:', error);
        alert('Error loading tasks. Please try again.');
    }
}

// Add new task
async function addTask() {
    const titleInput = document.getElementById('taskTitle');
    const descriptionInput = document.getElementById('taskDescription');
    
    const title = titleInput.value.trim();
    const description = descriptionInput.value.trim();
    
    if (!title) {
        alert('Please enter a task title');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/tasks`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'user-id': userId
            },
            body: JSON.stringify({ title, description }),
        });
        
        if (!response.ok) throw new Error('Failed to add task');
        
        titleInput.value = '';
        descriptionInput.value = '';
        await fetchTasks();
        alert('Task added successfully!');
    } catch (error) {
        console.error('Error adding task:', error);
        alert('Error adding task. Please try again.');
    }
}

// Edit task
async function editTask(taskId) {
    const titleElement = document.getElementById(`title-${taskId}`);
    const descElement = document.getElementById(`desc-${taskId}`);
    
    const newTitle = prompt('Edit task title:', titleElement.textContent);
    if (!newTitle) return; // User cancelled
    
    const newDescription = prompt('Edit task description:', descElement.textContent);
    if (newDescription === null) return; // User cancelled
    
    try {
        const response = await fetch(`${API_URL}/tasks/${taskId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'user-id': userId
            },
            body: JSON.stringify({
                title: newTitle,
                description: newDescription,
                status: titleElement.closest('.task-card').classList.contains('completed') ? 'completed' : 'pending'
            }),
        });
        
        if (!response.ok) throw new Error('Failed to update task');
        
        await fetchTasks();
        alert('Task updated successfully!');
    } catch (error) {
        console.error('Error updating task:', error);
        alert('Error updating task. Please try again.');
    }
}

// Toggle task status
async function toggleTaskStatus(taskId, currentStatus) {
    const newStatus = currentStatus === 'completed' ? 'pending' : 'completed';
    const taskCard = document.querySelector(`.task-card:has(#title-${taskId})`);
    const title = taskCard.querySelector(`#title-${taskId}`).textContent;
    const description = taskCard.querySelector(`#desc-${taskId}`).textContent;
    
    try {
        const response = await fetch(`${API_URL}/tasks/${taskId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'user-id': userId
            },
            body: JSON.stringify({
                title,
                description,
                status: newStatus
            }),
        });
        
        if (!response.ok) throw new Error('Failed to update task status');
        
        await fetchTasks();
    } catch (error) {
        console.error('Error updating task status:', error);
        alert('Error updating task status. Please try again.');
    }
}

// Delete task
async function deleteTask(taskId) {
    if (!confirm('Are you sure you want to delete this task?')) return;
    
    try {
        const response = await fetch(`${API_URL}/tasks/${taskId}`, {
            method: 'DELETE',
            headers: {
                'user-id': userId
            }
        });
        
        if (!response.ok) throw new Error('Failed to delete task');
        
        await fetchTasks();
        alert('Task deleted successfully!');
    } catch (error) {
        console.error('Error deleting task:', error);
        alert('Error deleting task. Please try again.');
    }
}

// Logout function
function logout() {
    localStorage.removeItem('userId');
    localStorage.removeItem('username');
    window.location.href = '/login.html';
}



// Load tasks when page loads
document.addEventListener('DOMContentLoaded', fetchTasks);